"""Hostel Management & Room Allocation System - backend (stdlib only).
Run:  python server.py   ->  http://localhost:8000
"""
import hashlib, json, os, re, sqlite3
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

BASE = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE, "hostel.db")
STATIC = os.path.join(BASE, "static")

def conn():
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys = ON")
    return c

def init_db():
    fresh = not os.path.exists(DB_PATH)
    c = conn()
    c.executescript(open(os.path.join(BASE, "schema.sql")).read())
    if fresh:
        c.executemany("INSERT INTO hostel(hostel_name,location) VALUES (?,?)",
            [("Aryabhatta Boys Hostel", "North Campus"), ("Sarojini Girls Hostel", "South Campus")])
        for h in (1, 2):
            for f in (1, 2):
                for r in range(1, 5):
                    c.execute("INSERT INTO room(hostel_id,room_no,capacity,floor) VALUES (?,?,?,?)",
                              (h, f"{f}0{r}", 2 if r % 2 else 3, f))
        c.executemany("INSERT INTO student(student_name,course,year_of_study,phone) VALUES (?,?,?,?)", [
            ("Rohan Patil", "B.Tech CSE", 2, "9876500001"), ("Sneha Kulkarni", "B.Tech IT", 3, "9876500002"),
            ("Amit Deshmukh", "BBA", 1, "9876500003"), ("Priya Joshi", "B.Sc Physics", 2, "9876500004"),
            ("Karan Mehta", "B.Tech Mech", 4, "9876500005")])
        c.executemany("INSERT INTO allocation(student_id,room_id) VALUES (?,?)", [(1, 1), (2, 9), (3, 1)])
        c.executemany("INSERT INTO payment(student_id,amount,payment_status) VALUES (?,?,?)",
                      [(1, 45000, "Paid"), (2, 45000, "Paid"), (3, 45000, "Pending")])
        c.executemany("INSERT INTO complaint(student_id,category,complaint_text,status) VALUES (?,?,?,?)",
                      [(1, "Plumbing", "Tap leaking in washroom.", "Open"), (2, "Electrical", "Fan not working.", "In Progress")])
        c.execute("INSERT INTO user(username,password,role) VALUES ('admin',?, 'admin')",
                  (hashlib.sha256(b"admin123").hexdigest(),))
        c.commit()
    c.close()

def rows(c, sql):
    return [dict(r) for r in c.execute(sql)]

def state():
    c = conn()
    out = {
        "hostels": rows(c, "SELECT hostel_id id, hostel_name name, location loc FROM hostel"),
        "rooms": rows(c, "SELECT room_id id, hostel_id hid, room_no no, capacity cap, floor, occupied occ, status FROM room"),
        "students": rows(c, "SELECT student_id id, student_name name, course, year_of_study year, phone FROM student"),
        "allocs": rows(c, "SELECT allocation_id id, student_id sid, room_id rid, allocation_date date, release_date rel, status st FROM allocation"),
        "pays": rows(c, "SELECT payment_id id, student_id sid, amount amt, payment_date date, payment_status st FROM payment"),
        "comps": rows(c, "SELECT complaint_id id, student_id sid, category cat, complaint_date date, complaint_text txt, status st FROM complaint"),
    }
    c.close()
    return out

def need(d, *keys):
    for k in keys:
        if d.get(k) in (None, ""):
            raise ValueError(f"Missing field: {k}")

def add_student(c, d):
    need(d, "name", "course", "year", "phone")
    c.execute("INSERT INTO student(student_name,course,year_of_study,phone) VALUES (?,?,?,?)",
              (d["name"], d["course"], int(d["year"]), str(d["phone"])))

def allocate(c, d):
    need(d, "sid", "rid")
    c.execute("INSERT INTO allocation(student_id,room_id) VALUES (?,?)", (int(d["sid"]), int(d["rid"])))

def release(c, d, i):
    c.execute("UPDATE allocation SET status='Released', release_date=date('now') WHERE allocation_id=? AND status='Active'", (i,))

def add_payment(c, d):
    need(d, "sid", "amt", "st")
    c.execute("INSERT INTO payment(student_id,amount,payment_status) VALUES (?,?,?)",
              (int(d["sid"]), float(d["amt"]), d["st"]))

def mark_paid(c, d, i):
    c.execute("UPDATE payment SET payment_status='Paid', payment_date=date('now') WHERE payment_id=?", (i,))

def add_complaint(c, d):
    need(d, "sid", "cat", "txt")
    c.execute("INSERT INTO complaint(student_id,category,complaint_text) VALUES (?,?,?)",
              (int(d["sid"]), d["cat"], d["txt"]))

def advance(c, d, i):
    c.execute("""UPDATE complaint SET status = CASE status WHEN 'Open' THEN 'In Progress' ELSE 'Resolved' END
                 WHERE complaint_id=? AND status!='Resolved'""", (i,))

ROUTES = [
    ("POST", r"/api/students$", lambda c, d, m: add_student(c, d)),
    ("POST", r"/api/allocations$", lambda c, d, m: allocate(c, d)),
    ("POST", r"/api/allocations/(\d+)/release$", lambda c, d, m: release(c, d, int(m[1]))),
    ("POST", r"/api/payments$", lambda c, d, m: add_payment(c, d)),
    ("POST", r"/api/payments/(\d+)/paid$", lambda c, d, m: mark_paid(c, d, int(m[1]))),
    ("POST", r"/api/complaints$", lambda c, d, m: add_complaint(c, d)),
    ("POST", r"/api/complaints/(\d+)/advance$", lambda c, d, m: advance(c, d, int(m[1]))),
]

class H(BaseHTTPRequestHandler):
    def send(self, code, body, ctype="application/json"):
        data = body if isinstance(body, bytes) else json.dumps(body).encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if self.path == "/api/state":
            return self.send(200, state())
        path = "index.html" if self.path in ("/", "") else self.path.lstrip("/")
        f = os.path.normpath(os.path.join(STATIC, path))
        if not f.startswith(STATIC) or not os.path.isfile(f):
            return self.send(404, {"error": "Not found"})
        self.send(200, open(f, "rb").read(), "text/html; charset=utf-8" if f.endswith(".html") else "application/octet-stream")

    def do_POST(self):
        n = int(self.headers.get("Content-Length") or 0)
        try:
            d = json.loads(self.rfile.read(n) or b"{}")
        except ValueError:
            return self.send(400, {"error": "Invalid JSON"})
        for method, pat, fn in ROUTES:
            m = re.match(pat, self.path)
            if method == "POST" and m:
                c = conn()
                try:
                    fn(c, d, m)
                    c.commit()
                    return self.send(200, {"ok": True})
                except sqlite3.IntegrityError as e:
                    c.rollback()
                    msg = str(e)
                    if "ux_one_active_room" in msg or "allocation.student_id" in msg:
                        msg = "Student already has an active room"
                    return self.send(400, {"error": msg})
                except (sqlite3.DatabaseError, ValueError) as e:
                    c.rollback()
                    return self.send(400, {"error": str(e)})
                finally:
                    c.close()
        self.send(404, {"error": "Not found"})

    def log_message(self, *a):
        pass

if __name__ == "__main__":
    init_db()
    print("Hostel system running at http://localhost:8000")
    ThreadingHTTPServer(("0.0.0.0", 8000), H).serve_forever()
