# Hostel Management & Room Allocation System

Python (standard library only) + SQLite backend with an HTML/JS frontend.

## Run
    python server.py
Open http://localhost:8000  (requires Python 3.8+; no pip install needed).
The database file `hostel.db` is created and seeded automatically on first run. Delete it to reset.

## Structure
- `schema.sql`     – tables, constraints, unique index and triggers (matches your ER diagram)
- `server.py`      – REST API + static file server
- `static/index.html` – frontend

## Database rules enforced in SQL
- Foreign keys on all relationships; `user.student_id` is UNIQUE (student 1 : 0..1 user)
- One active room per student (partial unique index)
- Triggers block allocation to a full room and keep `room.occupied` / `room.status` in sync on allocate and release

## API
GET  /api/state
POST /api/students | /api/allocations | /api/payments | /api/complaints
POST /api/allocations/<id>/release | /api/payments/<id>/paid | /api/complaints/<id>/advance
